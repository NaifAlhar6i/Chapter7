var searchData=
[
  ['initializegl',['initializeGL',['../class_g_l_widget.html#a5e4f13ffe657140447c4f572c70791c6',1,'GLWidget']]],
  ['initializeglobjects',['InitializeGLObjects',['../class_g_l_manager.html#a23895cb77eaafee480d6cfd18f2e7f19',1,'GLManager']]],
  ['installopencl',['InstallOpenCL',['../class_c_l_task.html#a8ba9ca4c930a1069be3a01e338ff96e0',1,'CLTask']]]
];
