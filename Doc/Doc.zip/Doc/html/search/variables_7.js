var searchData=
[
  ['radius',['Radius',['../struct_s_t_r_u_c_t___g_p_u_protein_space.html#a33fd85abc62626cb0fa4e915287a6121',1,'STRUCT_GPUProteinSpace::Radius()'],['../struct_s_t_r_u_c_t___g_p_u_lipid_space.html#a6b1f6b6b55ce3160cc03a1b8f49d7360',1,'STRUCT_GPULipidSpace::Radius()']]]
];
