var searchData=
[
  ['onfiledataread',['OnFileDataRead',['../class_main_window.html#a72460b139c2231f88abc33c7f717caac',1,'MainWindow']]],
  ['onglinitialized',['OnGLinitialized',['../class_main_window.html#a90b5572287ea2284ef57988e26d67648',1,'MainWindow']]]
];
