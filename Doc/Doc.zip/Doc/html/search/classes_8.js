var searchData=
[
  ['xdr',['XDR',['../struct_x_d_r.html',1,'']]],
  ['xdr_5fops',['xdr_ops',['../struct_x_d_r_1_1xdr__ops.html',1,'XDR']]],
  ['xdrfile',['XDRFILE',['../struct_x_d_r_f_i_l_e.html',1,'']]],
  ['xtcmanager',['XTCManager',['../class_x_t_c_manager.html',1,'']]]
];
