var searchData=
[
  ['zoom',['zoom',['../class_g_l_widget.html#a28ae386e1a5b7bd4d1ab09a2be731547',1,'GLWidget::zoom()'],['../class_transformation.html#a2de1b09ce14ff0a117ea59fce8535ce5',1,'Transformation::Zoom()']]]
];
