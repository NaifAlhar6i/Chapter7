var searchData=
[
  ['b',['B',['../struct_s_t_r_u_c_t___vetex_color.html#afc49605b8c26927e953bdae59a32f530',1,'STRUCT_VetexColor']]],
  ['buf1',['buf1',['../struct_x_d_r_f_i_l_e.html#a7274b510f55945af86ae20a6da81d429',1,'XDRFILE']]],
  ['buf1size',['buf1size',['../struct_x_d_r_f_i_l_e.html#a9012ee5348a016a94c5ca634def2c1e4',1,'XDRFILE']]],
  ['buf2',['buf2',['../struct_x_d_r_f_i_l_e.html#a6e8d580fdf18234acfda1f382d89a2d8',1,'XDRFILE']]],
  ['buf2size',['buf2size',['../struct_x_d_r_f_i_l_e.html#a71cedf31f2b15a635fa4fe20094a3133',1,'XDRFILE']]]
];
