var searchData=
[
  ['xtcmanager',['XTCManager',['../class_x_t_c_manager.html#a5908f70e5334eb504138344d193243ef',1,'XTCManager']]]
];
