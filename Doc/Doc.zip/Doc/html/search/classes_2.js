var searchData=
[
  ['framerate',['FrameRate',['../class_frame_rate.html',1,'']]]
];
