var searchData=
[
  ['zaxis',['ZAxis',['../struct_s_t_r_u_c_t___g_p_u_protein_space.html#af3f5dd3086c1c8872125ebcaf36fdc8d',1,'STRUCT_GPUProteinSpace']]],
  ['zoom',['zoom',['../class_g_l_widget.html#a28ae386e1a5b7bd4d1ab09a2be731547',1,'GLWidget::zoom()'],['../class_transformation.html#a2de1b09ce14ff0a117ea59fce8535ce5',1,'Transformation::Zoom()']]]
];
