var searchData=
[
  ['a',['A',['../struct_s_t_r_u_c_t___vetex_color.html#a0937e09a54e40e3edaf75a35f03d47fd',1,'STRUCT_VetexColor']]],
  ['avgproteincom',['avgProteinCOM',['../struct_s_t_r_u_c_t___g_p_u_protein_space.html#a2feae79ddca53c326e4526b437ec4d88',1,'STRUCT_GPUProteinSpace']]],
  ['avgradius',['avgRadius',['../struct_s_t_r_u_c_t___g_p_u_protein_space.html#a4e4bdeee700e72d3d58b5dcfd82db874',1,'STRUCT_GPUProteinSpace']]]
];
